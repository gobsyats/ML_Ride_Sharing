# run this file


import importZoneLatLong
print("Import ZoneLatLong successfull!!!")
import importZoneLookup
print("Import ZoneLookup successfull!!!")
import storeLatLongs_Edit
print("Import storeLatLongsEdit successfull!!!")
print("Generating Riders...Please Wait....This May Take A While!!!")
import generateRiders
print("Riders Generated!!!")
print("Generating Drivers...Please Wait....This May Take A While!!!")
import generateDrivers
print("Drivers Generated!!!")
