#Gobdyasay
#MAP_KEY = "AIzaSyCpHOHms5OXq1wR9qSMU1BErN0ubwzE8qI"

#MAP_KEY = "AIzaSyC4wipsFldEptdWUNh8UweCbLHCqAy4TzM"
#AIzaSyC4wipsFldEptdWUNh8UweCbLHCqAy4TzM

#govindyatnalkar7
#MAP_KEY = "AIzaSyCzHzKwiYxnXMcrZPOQ8_DdjXYDNTxeRgQ"

#govindyatnalkar8
#MAP_KEY = "AIzaSyDRtnzvCQeRvhJIz4wDrYUXlqtH0dR6D2U"

#govindyatnalkar9
#MAP_KEY = "AIzaSyBAJyrj_ZHa1Kn_smc8wcdlmNQwL86sJ94"
#govindyatnalkar10
#MAP_KEY = "AIzaSyDplZOpprOQvxpl8pM0ZafyxB60TAhupFw"

#MAP_KEY = "AIzaSyAZ7QaAwesPxj9l7jtmVENLiRUajIEqaAY"

#MAP_KEY = "AIzaSyCFH7BxfURF7mlwnnKo9ipwriKdhJ4ucW0"
#
#MAP_KEY =  "AIzaSyAbwZxWVK-rwCNfSj_d3D-jsx1fLkeOci8"
#
#MAP_KEY =  "AIzaSyAoD1j6pgsn6rvzUPFC4axWG6puE-cZmIk"

#K_UNUSED = "AIzaSyCPLzTzV_mlwIWKGulNf3hnCPJXw4vDwNc"

#K1_UNUSED = "AIzaSyDqqvXdF56y019PP54Tj1yQPGFDK7w9zUc"

#K2_UNUSED = "AIzaSyDsTCaKUWHmktk8_tzFpOJgpghOYGA9Jhs"

#MAP_KEY = "AIzaSyCmZTwSl6ho03exftHXz_xVT6rdKACqhuk"


#MAP_KEY = "AIzaSyCOHCky_6tBNvd34i4AV-nFhc1IXGZTS4A"

#MAP_KEY = "AIzaSyAtZZMvfQUyHNyxcbciqbsGo4Yb9Fymnkk"


#VIKRAM KEYS - STILL USABLE
#MAP_KEY = "AIzaSyAsfAVtoK38-eE9d2J4E1dD_lP66R1vI7w"
#
#
#
#

#NEIL Keys
#MAP_KEY="AIzaSyBHvt0huL05qve6tLHb_ikZiELLDIhM3qE"


#MAP_KEY="AIzaSyDXkgUgeU1_x4NT9fR37CaaHsIyRX88-fA"
#MAP_KEY="AIzaSyCFt0QRd1R_HPg3yu7GfJKSfQtRKbU_Io4"
#
#


#Ashish

#Vikram

#Darshan


#Nischal- 20, 400
#MAP_KEY = "AIzaSyBwy1q8kV8a5kolBpR8G0u35D8uAcX1NcA"
#Vasanth - Usable
#onwards - 20,400
#MAP_KEY = "AIzaSyBRUMpdD6OGzv28dO39KjZieyEnANH6klA"
#Raag - Usable
#MAP_KEY = "AIzaSyBvjkk0HA2gYFBClE-R00OXu7q3xH_--g8"

#DEFENSE_KEY
MAP_KEY = "AIzaSyDSTgF3_PtDFmkRu16YhCrEwR8Alc-FOlI"

CHATTY_SCORE = "chatty_score"
SECURITY_SCORE = "security_score"
ALSO_DRIVER = 'alsoDriver'
USER_ID = 'userId'
MONGO_ID = '_id'
SECURITY_SCORE = 'safety_score'
SAFETY_SCORE = 'safety_score'
PUNCTUALITY_SCORE = 'punctuality_score'
FRIENDLINESS_SCORE = 'friendliness_score'
COMFORTIBILITY_SCORE = 'comfortibility_score'
SEAT_CAPACITY = 'seatCapacity'
UTT = 'UTT'
SOURCE_ZONE = 'sourceZone'
DESTINATION_ZONE = 'destinationZone'
ZONE_ID = 'zoneId'
LOCATION_COUNT = 'location_count'
COORDINATES = 'coordinates'
YES = "Yes"
NO = "No"
DRIVER = "driver"
RIDER = "rider"
RIDERS= "riders"
ROLE = "role"
TOTAL_USERS = 400001
TOTAL_ZONES = 263
EMPTY_STRING = ""
ACTIVE_STATE = "active_state"
CURRENT_LOCATION = "current_location"
RANDOM_ZONE = "random_zone"
CURRENT_ZONE = "current_zone"
#Importing GeoJSON String
FEATURES = "features"
PROPERTIES = "properties"
ZONE_NAME = "zone_name"
BOROUGH = "borough"
CURRENT_TIME = "current_time"
BROADCASTING = "broadcasting"
SOURCE = "source"
DESTINATION = "destination"
SOURCE_ADDRESS = "source_address"
DEST_ADDRESS = "dest_address"

TRIP_START_TIME = "trip_start_time"
TRIP_END_TIME = "trip_end_time"
TOTAL_RIDERS_IN_POOL = 'Total_Riders_In_Pool'
TRIP_DIFF_SECS = "trip_diff(secs)"
TRIP_DIFF_MINS = "trip_diff(mins)"
TOTAL_RIDERS_CHECKED = "total_riders_checked"
TOTAL_RIDERS_MATCHED = "total_rider_match_count"
TOTAL_DRIVERS = "total_drivers"
FOR_RIDER_COUNT = "for_riders"
TIME_STRING = "%Y-%m-%d %H:%M:%S"
ZERO_RESULTS = "ZERO_RESULTS"

EXACT = "EXACT"
CLOSER = "CLOSER"
ALTERNATIVE = "ALTERNATIVE"

USER_SCORE = "user_score"
USER_FEEDBACK = "user_feedback"
RIDER_FEEDBACK = "rider_feedback"
DRIVER_FEEDBACL = "driver_feedback"
TIME_STAMP = "time_stamp"

JUST_UTT = "justUTT"
FIND_DRIVER = "find_driver"
SZEC = "same_zone_exact_characteristics"
ALL_BROADCASTING = "all_broadcasting"
OTHER_ZONE = "other_zone"
SAME_ZONE = "same_zone"

USER_WAIT_TIME_SECS = "user_waiting_time(secs)"
USER_WAIT_TIME_MINS = "user_waiting_time(mins)"

TRIP_ID = "trip_id"
TRIP_MONGOID = "trip_mongoId"

CHAT_RATE = "chatty_rating"
SAFE_RATE = "safety_rating"
PUNCTUAL_RATE = "punctuality_rating"
COMFORT_RATE = "comfort_rating"
FRIENDLINESS_RATE = "friendliness_rating"

FEEDBACK_GIVEN = "feedback_given"
CLASSIFIER = "got_feedback_classifier"
GOT_FEEDBACK_CLASSIFIER = "got_feedback_classifier"
GOT_FEEDBACK_CLASSIFIER_INT = "got_feedback_classifier_int"
GOT_FEEDBACK_CLASSIFIER_SCORE = "got_feedback_classifier_score"
FEEDBACK_GOT_CHAT = "got_rating_chat"
FEEDBACK_GOT_SAFE = "got_rating_safe"
FEEDBACK_GOT_PUNCTUAL = "got_rating_punctual"
FEEDBACK_GOT_COMFORT = "got_rating_comfort"
FEEDBACK_GOT_FRIEND = "got_rating_friend"
RATINGS_GOT_DICT = "ratings_got_dict"

GIVEN_RATING_CHAT = "chat_rating_given"
GIVEN_RATING_SAFE = "safety_rating_given"
GIVEN_RATING_PUNCTUAL = "punctual_rating_given"
GIVEN_RATING_FRIEND = "friend_rating_given"
GIVEN_RATING_COMFORT = "comfort_rating_given"
GIVEN_FEEDBACK_CLASSIFIER = "giving_feedback_classifier"
GIVEN_FEEDBACK_CLASSIFIER_INT = "giving_feedback_classifier_int"
GIVEN_FEEDBACK_CLASSIFIER_SCORE = "giving_feedback_classifier_score"
CLASSIFIER_CURRENT_OUTPUT = "given_feedback_classifier_rounded"

DRIVER_OVERALL_RATING = "driver_overall_rating"
MATCHING_SCORE = "matching_score"

THE_SEQUENCE = "chatty", "safety", "punctuality", "friendliness", "comfortability"
CHAR_DICT = "char_dict"
REG_CLASSIFIER = "registration_classifier"
FEEDBACK_CLASSIFIER = "feedback_classifier"

VARIANCE_DICT = "variance_dict"

SCORE = "score"

