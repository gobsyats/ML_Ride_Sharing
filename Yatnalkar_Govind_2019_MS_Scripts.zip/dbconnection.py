from pymongo import MongoClient

client = MongoClient()
db = client.vehicleShare_V4